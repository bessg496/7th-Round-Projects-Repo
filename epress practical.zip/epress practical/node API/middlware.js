const express = require('express');
const app = express();
const port = 5000;
const loggerMiddleware = (req, res, next) => {
  console.log('Request received');
  next();
};
app.use(loggerMiddleware);
app.get('/', (req, res) => {
  res.send('Hello Express');
});
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/`);});