const taskInput = document.getElementById("taskInput");
const prioritySelect = document.getElementById("prioritySelect");
const addTaskBtn = document.getElementById("addTaskBtn");
const taskList = document.getElementById("taskList");

addTaskBtn.addEventListener("click", () => {
  const taskText = taskInput.value.trim();
  const priority = prioritySelect.value;

  if (taskText === "") {
    alert("Task cannot be empty!");
    return;
  }
  const li = document.createElement("li");
  li.setAttribute("data-priority", priority);

  const span = document.createElement("span");
  span.textContent = `${taskText} `;
  
  const priorityLabel = document.createElement("span");
  priorityLabel.textContent = `[${priority}]`;
  priorityLabel.classList.add("priority");

  // Mark complete on click
  li.addEventListener("click", () => {
    li.classList.toggle("completed");
  });
  const deleteBtn = document.createElement("button");
  deleteBtn.textContent = "Delete";
  deleteBtn.classList.add("deleteBtn");
  deleteBtn.addEventListener("click", (e) => {
    e.stopPropagation(); // prevent toggling complete
    li.remove();
  });

  li.appendChild(span);
  li.appendChild(priorityLabel);
  li.appendChild(deleteBtn);
  taskList.appendChild(li);

  sortTasks();

  taskInput.value = ""; // clear input
});
function sortTasks() {
  const tasks = Array.from(taskList.children);
  const priorityOrder = { High: 1, Medium: 2, Low: 3 };

  tasks.sort((a, b) => {
    return priorityOrder[a.dataset.priority] - priorityOrder[b.dataset.priority];
  });

  tasks.forEach(task => taskList.appendChild(task));
}
